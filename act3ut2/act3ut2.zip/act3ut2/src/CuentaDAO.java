import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CuentaDAO {
    private final String url = "jdbc:sqlite:banco.db";

    public void crearCuenta(Cuenta c) {
        String sql = "INSERT INTO cuentas (idpropietario, saldo, tipoCuenta, idsucursal) VALUES (?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(url);
            PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, c.getIdpropietario());
            pstmt.setDouble(2, c.getSaldo());
            pstmt.setString(3, c.getTipoCuenta());
            pstmt.setInt(4, c.getIdsucursal());
            pstmt.executeUpdate();
            System.out.println("Cuenta creada correctamente.");
        } catch (SQLException e) {
            System.out.println("Error creando cuenta: " + e.getMessage());
        }
    }

    public List<Cuenta> listarCuentas() {
        return obtenerLista("SELECT * FROM cuentas");
    }

    public List<Cuenta> obtenerCuentasUsuario(int idUsuario) {
        return obtenerLista("SELECT * FROM cuentas WHERE idpropietario = " + idUsuario);
    }

    public double consultarSaldo(int idcuenta) {
        String sql = "SELECT saldo FROM cuentas WHERE idcuenta = ?";
        try (Connection conn = DriverManager.getConnection(url);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, idcuenta);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) return rs.getDouble("saldo");
        } catch (SQLException e) {
            System.out.println("Error consultando saldo: " + e.getMessage());
        }
        return -1;
    }

    public void ingresar(int idcuenta, double cantidad) {
        actualizarSaldo(idcuenta, cantidad, true);
    }

    public void retirar(int idcuenta, double cantidad) {
        actualizarSaldo(idcuenta, cantidad, false);
    }

    private void actualizarSaldo(int idcuenta, double cantidad, boolean ingresar) {
        String operacion = ingresar ? "Ingreso" : "Retiro";
        double signo = ingresar ? cantidad : -cantidad;

        String sql = "UPDATE cuentas SET saldo = saldo + ? WHERE idcuenta = ?";
        try (Connection conn = DriverManager.getConnection(url);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setDouble(1, signo);
            pstmt.setInt(2, idcuenta);
            pstmt.executeUpdate();
            System.out.printf("%s de %.2f€ realizado correctamente.%n", operacion, cantidad);
        } catch (SQLException e) {
            System.out.println("Error en " + operacion.toLowerCase() + ": " + e.getMessage());
        }
    }

    private List<Cuenta> obtenerLista(String sql) {
        List<Cuenta> lista = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection(url);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                lista.add(new Cuenta(
                    rs.getInt("idcuenta"),
                    rs.getInt("idpropietario"),
                    rs.getDouble("saldo"),
                    rs.getString("tipoCuenta"),
                    rs.getInt("idsucursal")
                ));
            }
        } catch (SQLException e) {
            System.out.println("Error obteniendo cuentas: " + e.getMessage());
        }
        return lista;
    }

    public void listarUsuariosConCuentas() {
        String sql = """
            SELECT u.nombre, c.idcuenta, c.saldo, c.tipoCuenta
            FROM usuarios u
            JOIN cuentas c ON u.idusuario = c.idpropietario
        """;
        try (Connection conn = DriverManager.getConnection(url);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                System.out.printf("%s -> Cuenta %d (%.2f€, %s)%n",
                    rs.getString("nombre"), rs.getInt("idcuenta"),
                    rs.getDouble("saldo"), rs.getString("tipoCuenta"));
            }
        } catch (SQLException e) {
            System.out.println("Error listando usuarios con cuentas: " + e.getMessage());
        }
    }

    public void listarCuentasConSucursal() {
        String sql = """
            SELECT c.idcuenta, c.saldo, c.tipoCuenta, s.nombre AS sucursal
            FROM cuentas c
            LEFT JOIN sucursales s ON c.idsucursal = s.idsucursal
        """;
        try (Connection conn = DriverManager.getConnection(url);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                System.out.printf("Cuenta %d | %.2f€ | %s | Sucursal: %s%n",
                    rs.getInt("idcuenta"),
                    rs.getDouble("saldo"),
                    rs.getString("tipoCuenta"),
                    rs.getString("sucursal"));
            }
        } catch (SQLException e) {
            System.out.println("Error listando cuentas con sucursal: " + e.getMessage());
        }
    }

    public void listarCuentasConSucursalDeUsuario(int idUsuario) {
        String sql = """
            SELECT c.idcuenta, c.saldo, c.tipoCuenta, s.nombre AS sucursal
            FROM cuentas c
            LEFT JOIN sucursales s ON c.idsucursal = s.idsucursal
            WHERE c.idpropietario = ?
        """;
        try (Connection conn = DriverManager.getConnection(url);
            PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idUsuario);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                System.out.printf("Cuenta %d | %.2f€ | %s | Sucursal: %s%n",
                    rs.getInt("idcuenta"),
                    rs.getDouble("saldo"),
                    rs.getString("tipoCuenta"),
                    rs.getString("sucursal"));
            }
        } catch (SQLException e) {
            System.out.println("Error listando cuentas del usuario: " + e.getMessage());
        }
    }
}
