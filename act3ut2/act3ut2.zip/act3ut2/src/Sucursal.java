public class Sucursal {
    private int idsucursal;
    private String nombre;
    private String direccion;

    public Sucursal(String nombre, String direccion) {
        this.nombre = nombre;
        this.direccion = direccion;
    }

    public Sucursal(int idsucursal, String nombre, String direccion) {
        this.idsucursal = idsucursal;
        this.nombre = nombre;
        this.direccion = direccion;
    }

    public int getIdsucursal() { return idsucursal; }
    public String getNombre() { return nombre; }
    public String getDireccion() { return direccion; }

    @Override
    public String toString() {
        return String.format("Sucursal{id=%d, nombre='%s', direccion='%s'}",
                idsucursal, nombre, direccion);
    }
}
