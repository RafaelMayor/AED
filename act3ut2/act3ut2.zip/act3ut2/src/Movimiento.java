public class Movimiento {
    private int idmovimiento;
    private int idcuenta;
    private String tipo;
    private double cantidad;
    private String fecha;

    public Movimiento(int idcuenta, String tipo, double cantidad) {
        this.idcuenta = idcuenta;
        this.tipo = tipo;
        this.cantidad = cantidad;
    }

    public Movimiento(int idmovimiento, int idcuenta, String tipo, double cantidad, String fecha) {
        this.idmovimiento = idmovimiento;
        this.idcuenta = idcuenta;
        this.tipo = tipo;
        this.cantidad = cantidad;
        this.fecha = fecha;
    }

    public int getIdmovimiento() { return idmovimiento; }
    public int getIdcuenta() { return idcuenta; }
    public String getTipo() { return tipo; }
    public double getCantidad() { return cantidad; }
    public String getFecha() { return fecha; }

    @Override
    public String toString() {
        return String.format("Movimiento{id=%d, cuenta=%d, tipo='%s', cantidad=%.2f, fecha='%s'}",
                idmovimiento, idcuenta, tipo, cantidad, fecha);
    }
}
