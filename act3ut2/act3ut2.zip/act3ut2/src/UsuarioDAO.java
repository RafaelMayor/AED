import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO {
    private final String url = "jdbc:sqlite:banco.db";

    public UsuarioDAO() {
        crearTablas();
        crearAdminPorDefecto();
    }

    private void crearTablas() {
        String sqlUsuarios = """
            CREATE TABLE IF NOT EXISTS usuarios (
                idusuario INTEGER PRIMARY KEY AUTOINCREMENT,
                nombre TEXT NOT NULL UNIQUE,
                password TEXT NOT NULL,
                rol TEXT CHECK(rol IN ('empleado','cliente')) NOT NULL
            );
        """;

        String sqlSucursales = """
            CREATE TABLE IF NOT EXISTS sucursales (
                idsucursal INTEGER PRIMARY KEY AUTOINCREMENT,
                nombre TEXT NOT NULL,
                direccion TEXT
            );
        """;

        String sqlCuentas = """
            CREATE TABLE IF NOT EXISTS cuentas (
                idcuenta INTEGER PRIMARY KEY AUTOINCREMENT,
                idpropietario INTEGER NOT NULL,
                saldo REAL DEFAULT 0,
                tipoCuenta TEXT,
                idsucursal INTEGER,
                FOREIGN KEY (idpropietario) REFERENCES usuarios(idusuario) ON DELETE CASCADE,
                FOREIGN KEY (idsucursal) REFERENCES sucursales(idsucursal)
            );
        """;

        String sqlMovimientos = """
            CREATE TABLE IF NOT EXISTS movimientos (
                idmovimiento INTEGER PRIMARY KEY AUTOINCREMENT,
                idcuenta INTEGER,
                tipo TEXT,
                cantidad REAL,
                fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(idcuenta) REFERENCES cuentas(idcuenta)
            );
        """;

        try (Connection conn = DriverManager.getConnection(url);
            Statement stmt = conn.createStatement()) {
            stmt.execute(sqlUsuarios);
            stmt.execute(sqlSucursales);
            stmt.execute(sqlCuentas);
            stmt.execute(sqlMovimientos);
        } catch (SQLException e) {
            System.out.println("Error creando tablas: " + e.getMessage());
        }
    }


    private void crearAdminPorDefecto() {
        String check = "SELECT COUNT(*) FROM usuarios WHERE nombre = 'admin'";
        try (Connection conn = DriverManager.getConnection(url);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(check)) {
            if (rs.next() && rs.getInt(1) == 0) {
                String insert = "INSERT INTO usuarios (nombre, password, rol) VALUES ('admin', '1234', 'empleado')";
                stmt.executeUpdate(insert);
                System.out.println("Usuario administrador creado automáticamente (admin / 1234).");
            }
        } catch (SQLException e) {
            System.out.println("Error creando admin: " + e.getMessage());
        }
    }

    public void crearUsuario(Usuario u) {
        String sql = "INSERT INTO usuarios (nombre, password, rol) VALUES (?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(url);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, u.getNombre());
            pstmt.setString(2, u.getPassword());
            pstmt.setString(3, u.getRol());
            pstmt.executeUpdate();
            System.out.println("Usuario creado correctamente.");
        } catch (SQLException e) {
            System.out.println("Error creando usuario: " + e.getMessage());
        }
    }

    public List<Usuario> listarUsuarios() {
        List<Usuario> lista = new ArrayList<>();
        String sql = "SELECT * FROM usuarios";
        try (Connection conn = DriverManager.getConnection(url);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                lista.add(new Usuario(
                    rs.getInt("idusuario"),
                    rs.getString("nombre"),
                    rs.getString("password"),
                    rs.getString("rol")
                ));
            }
        } catch (SQLException e) {
            System.out.println("Error listando usuarios: " + e.getMessage());
        }
        return lista;
    }

    public Usuario autenticar(String nombre, String password) {
        String sql = "SELECT * FROM usuarios WHERE nombre = ? AND password = ?";
        try (Connection conn = DriverManager.getConnection(url);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, nombre);
            pstmt.setString(2, password);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return new Usuario(
                    rs.getInt("idusuario"),
                    rs.getString("nombre"),
                    rs.getString("password"),
                    rs.getString("rol")
                );
            }
        } catch (SQLException e) {
            System.out.println("Error autenticando: " + e.getMessage());
        }
        return null;
    }

    public void eliminarUsuario(int idusuario) {
        String sql1 = "DELETE FROM cuentas WHERE idpropietario = ?";
        String sql2 = "DELETE FROM usuarios WHERE idusuario = ?";
        try (Connection conn = DriverManager.getConnection(url);
             PreparedStatement pstmt1 = conn.prepareStatement(sql1);
             PreparedStatement pstmt2 = conn.prepareStatement(sql2)) {
            pstmt1.setInt(1, idusuario);
            pstmt1.executeUpdate();
            pstmt2.setInt(1, idusuario);
            pstmt2.executeUpdate();
            System.out.println("Usuario eliminado (y sus cuentas asociadas).");
        } catch (SQLException e) {
            System.out.println("Error eliminando usuario: " + e.getMessage());
        }
    }
}
