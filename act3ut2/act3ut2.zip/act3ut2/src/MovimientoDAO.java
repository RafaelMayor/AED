import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MovimientoDAO {
    private final String url = "jdbc:sqlite:banco.db";

    // Crear tabla si no existe
    public MovimientoDAO() {
        try (Connection conn = DriverManager.getConnection(url);
             Statement st = conn.createStatement()) {
            st.execute("""
                CREATE TABLE IF NOT EXISTS movimientos (
                    idmovimiento INTEGER PRIMARY KEY AUTOINCREMENT,
                    idcuenta INTEGER,
                    tipo TEXT,
                    cantidad REAL,
                    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY(idcuenta) REFERENCES cuentas(idcuenta)
                )
            """);
        } catch (SQLException e) {
            System.out.println("Error creando tabla movimientos: " + e.getMessage());
        }
    }

    // Registrar movimiento
    public void registrarMovimiento(Movimiento m) {
        String sql = "INSERT INTO movimientos (idcuenta, tipo, cantidad) VALUES (?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(url);
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, m.getIdcuenta());
            ps.setString(2, m.getTipo());
            ps.setDouble(3, m.getCantidad());
            ps.executeUpdate();
            System.out.println("Movimiento registrado: " + m.getTipo() + " (" + m.getCantidad() + "€)");
        } catch (SQLException e) {
            System.out.println("Error registrando movimiento: " + e.getMessage());
        }
    }

    // Listar todos los movimientos
    public List<Movimiento> listarMovimientos() {
        List<Movimiento> lista = new ArrayList<>();
        String sql = "SELECT * FROM movimientos ORDER BY fecha DESC";
        try (Connection conn = DriverManager.getConnection(url);
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                lista.add(new Movimiento(
                        rs.getInt("idmovimiento"),
                        rs.getInt("idcuenta"),
                        rs.getString("tipo"),
                        rs.getDouble("cantidad"),
                        rs.getString("fecha")
                ));
            }
        } catch (SQLException e) {
            System.out.println("Error listando movimientos: " + e.getMessage());
        }
        return lista;
    }

    // Listar movimientos de un usuario (JOIN)
    public List<Movimiento> movimientosDeUsuario(int idUsuario) {
        List<Movimiento> lista = new ArrayList<>();
        String sql = """
            SELECT m.idmovimiento, m.idcuenta, m.tipo, m.cantidad, m.fecha
            FROM movimientos m
            JOIN cuentas c ON m.idcuenta = c.idcuenta
            WHERE c.idpropietario = ?
            ORDER BY m.fecha DESC
        """;
        try (Connection conn = DriverManager.getConnection(url);
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idUsuario);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                lista.add(new Movimiento(
                        rs.getInt("idmovimiento"),
                        rs.getInt("idcuenta"),
                        rs.getString("tipo"),
                        rs.getDouble("cantidad"),
                        rs.getString("fecha")
                ));
            }
        } catch (SQLException e) {
            System.out.println("Error obteniendo movimientos del usuario: " + e.getMessage());
        }
        return lista;
    }
}
