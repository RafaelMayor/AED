import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SucursalDAO {
    private final String url = "jdbc:sqlite:banco.db";

    // Crear tabla si no existe
    public SucursalDAO() {
        try (Connection conn = DriverManager.getConnection(url);
             Statement st = conn.createStatement()) {
            st.execute("""
                CREATE TABLE IF NOT EXISTS sucursales (
                    idsucursal INTEGER PRIMARY KEY AUTOINCREMENT,
                    nombre TEXT NOT NULL,
                    direccion TEXT
                )
            """);
        } catch (SQLException e) {
            System.out.println("Error creando tabla sucursales: " + e.getMessage());
        }
    }

    // Crear sucursal
    public void crearSucursal(Sucursal s) {
        String sql = "INSERT INTO sucursales (nombre, direccion) VALUES (?, ?)";
        try (Connection conn = DriverManager.getConnection(url);
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, s.getNombre());
            ps.setString(2, s.getDireccion());
            ps.executeUpdate();
            System.out.println("Sucursal creada correctamente.");
        } catch (SQLException e) {
            System.out.println("Error creando sucursal: " + e.getMessage());
        }
    }

    // Listar sucursales
    public List<Sucursal> listarSucursales() {
        List<Sucursal> lista = new ArrayList<>();
        String sql = "SELECT * FROM sucursales";
        try (Connection conn = DriverManager.getConnection(url);
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                lista.add(new Sucursal(
                        rs.getInt("idsucursal"),
                        rs.getString("nombre"),
                        rs.getString("direccion")
                ));
            }
        } catch (SQLException e) {
            System.out.println("Error listando sucursales: " + e.getMessage());
        }
        return lista;
    }
}
