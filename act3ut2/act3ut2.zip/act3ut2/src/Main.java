import java.sql.*;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        UsuarioDAO usuarioDAO = new UsuarioDAO();
        CuentaDAO cuentaDAO = new CuentaDAO();
        MovimientoDAO movimientoDAO = new MovimientoDAO();
        SucursalDAO sucursalDAO = new SucursalDAO();

        System.out.println("Bienvenido al Banco JDBC");
        System.out.print("Usuario: ");
        String nombre = sc.nextLine();
        System.out.print("Contraseña: ");
        String pass = sc.nextLine();

        Usuario user = usuarioDAO.autenticar(nombre, pass);

        if (user == null) {
            System.out.println("Credenciales incorrectas.");
            return;
        }

        System.out.println("Bienvenido, " + user.getNombre() + " (" + user.getRol() + ")");

        if (user.getRol().equalsIgnoreCase("empleado")) {
            menuEmpleado(sc, usuarioDAO, cuentaDAO, movimientoDAO, sucursalDAO);
        } else {
            menuCliente(sc, cuentaDAO, movimientoDAO, user);
        }
    }

    // MENÚ EMPLEADO
    private static void menuEmpleado(Scanner sc, UsuarioDAO usuarioDAO,
                                     CuentaDAO cuentaDAO, MovimientoDAO movDAO,
                                     SucursalDAO sucDAO) {
        int opcion;
        do {
            System.out.println("""
            \nMENÚ EMPLEADO
            1. Crear nuevo usuario
            2. Listar usuarios
            3. Crear cuenta bancaria
            4. Listar cuentas
            5. Consultar cuentas de un usuario
            6. Eliminar usuario
            7. Listar usuarios con sus cuentas
            8. Listar cuentas con su sucursal
            9. Consultar movimientos de un usuario
            10. Ver metadatos (tablas y columnas)
            11. Crear nueva sucursal
            12. Listar sucursales
            13. Salir
            """);
            System.out.print("Opción: ");
            opcion = Integer.parseInt(sc.nextLine());

            switch (opcion) {
                case 1 -> {
                    System.out.print("Nombre: ");
                    String nombre = sc.nextLine();
                    System.out.print("Contraseña: ");
                    String pass = sc.nextLine();
                    System.out.print("Rol (empleado/cliente): ");
                    String rol = sc.nextLine();
                    usuarioDAO.crearUsuario(new Usuario(nombre, pass, rol));
                }
                case 2 -> usuarioDAO.listarUsuarios().forEach(System.out::println);
                case 3 -> {
                    System.out.print("ID del propietario: ");
                    int id = Integer.parseInt(sc.nextLine());
                    System.out.print("Tipo de cuenta: ");
                    String tipo = sc.nextLine();
                    System.out.print("ID de sucursal: ");
                    int idsuc = Integer.parseInt(sc.nextLine());
                    cuentaDAO.crearCuenta(new Cuenta(id, 0.0, tipo, idsuc));
                }
                case 4 -> cuentaDAO.listarCuentas().forEach(System.out::println);
                case 5 -> {
                    System.out.print("ID de usuario: ");
                    int id = Integer.parseInt(sc.nextLine());
                    cuentaDAO.obtenerCuentasUsuario(id).forEach(System.out::println);
                }
                case 6 -> {
                    System.out.print("ID de usuario a eliminar: ");
                    int id = Integer.parseInt(sc.nextLine());
                    usuarioDAO.eliminarUsuario(id);
                }
                case 7 -> cuentaDAO.listarUsuariosConCuentas();
                case 8 -> cuentaDAO.listarCuentasConSucursal();
                case 9 -> {
                    System.out.print("ID de usuario: ");
                    int id = Integer.parseInt(sc.nextLine());
                    movDAO.movimientosDeUsuario(id).forEach(System.out::println);
                }
                case 10 -> mostrarMetadatos();
                case 11 -> {
                    System.out.print("Nombre de sucursal: ");
                    String n = sc.nextLine();
                    System.out.print("Dirección: ");
                    String d = sc.nextLine();
                    sucDAO.crearSucursal(new Sucursal(n, d));
                }
                case 12 -> sucDAO.listarSucursales().forEach(System.out::println);
                case 13 -> System.out.println("Saliendo del menú empleado...");
                default -> System.out.println("Opción no válida.");
            }
        } while (opcion != 13);
    }

    // MENÚ CLIENTE
    private static void menuCliente(Scanner sc, CuentaDAO cuentaDAO, MovimientoDAO movDAO, Usuario user) {
        int opcion;
        do {
            System.out.println("""
            \nMENÚ CLIENTE
            1. Consultar mis cuentas (con sucursal)
            2. Consultar saldo
            3. Ingresar dinero
            4. Retirar dinero
            5. Ver mis movimientos
            6. Transferir entre mis cuentas
            7. Ver estructura de tabla (movimientos o cuentas)
            8. Salir
            """);
            System.out.print("Opción: ");
            opcion = Integer.parseInt(sc.nextLine());

            switch (opcion) {
                case 1 -> cuentaDAO.listarCuentasConSucursalDeUsuario(user.getIdusuario());
                case 2 -> {
                    System.out.print("ID de cuenta: ");
                    int id = Integer.parseInt(sc.nextLine());
                    double saldo = cuentaDAO.consultarSaldo(id);
                    System.out.printf("Saldo actual: %.2f€%n", saldo);
                }
                case 3 -> {
                    System.out.print("ID de cuenta: ");
                    int id = Integer.parseInt(sc.nextLine());
                    System.out.print("Cantidad a ingresar: ");
                    double cant = Double.parseDouble(sc.nextLine());
                    cuentaDAO.ingresar(id, cant);
                    movDAO.registrarMovimiento(new Movimiento(id, "ingreso", cant));
                }
                case 4 -> {
                    System.out.print("ID de cuenta: ");
                    int id = Integer.parseInt(sc.nextLine());
                    System.out.print("Cantidad a retirar: ");
                    double cant = Double.parseDouble(sc.nextLine());
                    cuentaDAO.retirar(id, cant);
                    movDAO.registrarMovimiento(new Movimiento(id, "retiro", cant));
                }
                case 5 -> movDAO.movimientosDeUsuario(user.getIdusuario()).forEach(System.out::println);
                case 6 -> transferir(sc, user);
                case 7 -> mostrarMetadatos();
                case 8 -> System.out.println("Saliendo del menú cliente...");
                default -> System.out.println("Opción no válida.");
            }
        } while (opcion != 8);
    }

    // Transferencia con transacción
    private static void transferir(Scanner sc, Usuario user) {
        System.out.print("Cuenta origen: ");
        int origen = Integer.parseInt(sc.nextLine());
        System.out.print("Cuenta destino: ");
        int destino = Integer.parseInt(sc.nextLine());
        System.out.print("Cantidad a transferir: ");
        double cantidad = Double.parseDouble(sc.nextLine());

        String url = "jdbc:sqlite:banco.db";
        try (Connection conn = DriverManager.getConnection(url)) {
            conn.setAutoCommit(false);

            PreparedStatement retirar = conn.prepareStatement("UPDATE cuentas SET saldo = saldo - ? WHERE idcuenta = ?");
            PreparedStatement ingresar = conn.prepareStatement("UPDATE cuentas SET saldo = saldo + ? WHERE idcuenta = ?");
            PreparedStatement mov = conn.prepareStatement("INSERT INTO movimientos (idcuenta, tipo, cantidad) VALUES (?, ?, ?)");

            retirar.setDouble(1, cantidad);
            retirar.setInt(2, origen);
            ingresar.setDouble(1, cantidad);
            ingresar.setInt(2, destino);

            retirar.executeUpdate();
            ingresar.executeUpdate();

            mov.setInt(1, origen);
            mov.setString(2, "transferencia");
            mov.setDouble(3, -cantidad);
            mov.executeUpdate();

            mov.setInt(1, destino);
            mov.setString(2, "transferencia");
            mov.setDouble(3, cantidad);
            mov.executeUpdate();

            conn.commit();
            System.out.println("Transferencia realizada correctamente.");
        } catch (Exception e) {
            System.out.println("Error en la transferencia: " + e.getMessage());
        }
    }

    // Metadatos (tablas y columnas)
    private static void mostrarMetadatos() {
        String url = "jdbc:sqlite:banco.db";
        try (Connection conn = DriverManager.getConnection(url)) {
            DatabaseMetaData meta = conn.getMetaData();
            ResultSet tablas = meta.getTables(null, null, "%", new String[]{"TABLE"});
            while (tablas.next()) {
                String nombreTabla = tablas.getString("TABLE_NAME");
                System.out.println("\nTabla: " + nombreTabla);
                ResultSet columnas = meta.getColumns(null, null, nombreTabla, "%");
                while (columnas.next()) {
                    System.out.printf(" - %s (%s)%n",
                        columnas.getString("COLUMN_NAME"),
                        columnas.getString("TYPE_NAME"));
                }
            }
        } catch (SQLException e) {
            System.out.println("Error leyendo metadatos: " + e.getMessage());
        }
    }
}
