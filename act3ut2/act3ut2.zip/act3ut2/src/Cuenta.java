public class Cuenta {
    private int idcuenta;
    private int idpropietario;
    private double saldo;
    private String tipoCuenta;
    private int idsucursal;

    public Cuenta() {}

    public Cuenta(int idpropietario, double saldo, String tipoCuenta, int idsucursal) {
        this.idpropietario = idpropietario;
        this.saldo = saldo;
        this.tipoCuenta = tipoCuenta;
        this.idsucursal = idsucursal;
    }

    // Sobrecarga sin sucursal (por compatibilidad con versiones previas)
    public Cuenta(int idpropietario, double saldo, String tipoCuenta) {
        this(idpropietario, saldo, tipoCuenta, 0);
    }

    public Cuenta(int idcuenta, int idpropietario, double saldo, String tipoCuenta, int idsucursal) {
        this(idpropietario, saldo, tipoCuenta, idsucursal);
        this.idcuenta = idcuenta;
    }

    public int getIdcuenta() { return idcuenta; }
    public void setIdcuenta(int idcuenta) { this.idcuenta = idcuenta; }

    public int getIdpropietario() { return idpropietario; }
    public void setIdpropietario(int idpropietario) { this.idpropietario = idpropietario; }

    public double getSaldo() { return saldo; }
    public void setSaldo(double saldo) { this.saldo = saldo; }

    public String getTipoCuenta() { return tipoCuenta; }
    public void setTipoCuenta(String tipoCuenta) { this.tipoCuenta = tipoCuenta; }

    public int getIdsucursal() { return idsucursal; }
    public void setIdsucursal(int idsucursal) { this.idsucursal = idsucursal; }

    @Override
    public String toString() {
        return String.format("Cuenta #%d | Propietario ID: %d | Tipo: %s | Saldo: %.2f€ | Sucursal ID: %d",
                idcuenta, idpropietario, tipoCuenta, saldo, idsucursal);
    }
}
