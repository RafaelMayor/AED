import modelo.*;
import dao.*;
import util.HibernateUtil;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        MesaDAO mesaDAO = new MesaDAO();
        PlatoDAO platoDAO = new PlatoDAO();
        CamareroDAO camareroDAO = new CamareroDAO();
        ClienteDAO clienteDAO = new ClienteDAO();
        ComandaDAO comandaDAO = new ComandaDAO();

        Scanner sc = new Scanner(System.in);
        int opt;

        do {
            System.out.println("\n--- MENU RESTAURANTE ---");
            System.out.println("1. Insertar datos de ejemplo");
            System.out.println("2. Crear comanda (con items)");
            System.out.println("3. Listar comandas de una mesa");
            System.out.println("4. Listar platos por categoria");
            System.out.println("5. Total facturado por camarero (rango)");
            System.out.println("6. Total facturado por cliente (rango)");
            System.out.println("7. Comandas de cliente (mostrar mesa y camarero)");
            System.out.println("8. Listar mesas ocupadas con nº comandas");
            System.out.println("9. Actualizar estado mesa");
            System.out.println("10. Eliminar comanda");
            System.out.println("11. Total facturado agrupado por categoría");
            System.out.println("0. Salir");
            System.out.print("Opción: ");
            opt = Integer.parseInt(sc.nextLine());

            switch (opt) {
                case 1 -> {
                    Mesa m1 = new Mesa(1, 4, "libre");
                    Mesa m2 = new Mesa(2, 2, "ocupada");
                    mesaDAO.guardar(m1);
                    mesaDAO.guardar(m2);

                    platoDAO.guardar(new Plato("Ensalada", "Ensalada mixta", 6.5, "entrada"));
                    platoDAO.guardar(new Plato("Solomillo", "Solomillo a la brasa", 15.0, "principal"));
                    platoDAO.guardar(new Plato("Tiramisu", "Tiramisu de piña", 5.0, "postre"));
                    platoDAO.guardar(new Plato("Cerveza", "Cerveza Dorada", 2.5, "bebida"));

                    camareroDAO.guardar(new Camarero("Laura", "12345678Z"));
                    clienteDAO.guardar(new Cliente("Carlos", "600111222", "c@ejemplo.com"));

                    System.out.println("Datos de ejemplo insertados.");
                }

                case 2 -> {
                    System.out.print("ID mesa: ");
                    Long idMesa = Long.parseLong(sc.nextLine());
                    System.out.print("ID camarero: ");
                    Long idCam = Long.parseLong(sc.nextLine());
                    System.out.print("ID cliente: ");
                    Long idCli = Long.parseLong(sc.nextLine());

                    Mesa mesa = mesaDAO.obtener(idMesa);
                    Camarero camarero = camareroDAO.obtener(idCam);
                    Cliente cliente = clienteDAO.obtener(idCli);

                    if (mesa == null || camarero == null || cliente == null) {
                        System.out.println("IDs inválidos. No se puede crear la comanda.");
                        break;
                    }

                    // La mesa pasa a "ocupada" al crear una comanda
                    mesa.setEstado("ocupada");
                    mesaDAO.actualizar(mesa);

                    Comanda comanda = new Comanda(LocalDateTime.now(), mesa, camarero, cliente);

                    System.out.print("¿Cuántos platos en la comanda? ");
                    int n = Integer.parseInt(sc.nextLine());

                    for (int i = 0; i < n; i++) {
                        System.out.print("ID plato: ");
                        Long idPlato = Long.parseLong(sc.nextLine());
                        System.out.print("Cantidad: ");
                        int cantidad = Integer.parseInt(sc.nextLine());

                        Plato plato = platoDAO.obtener(idPlato);

                        if (plato != null) {
                            ComandaPlato cp = new ComandaPlato();
                            cp.setPlato(plato);
                            cp.setCantidad(cantidad);

                            comanda.addItem(cp);
                        } else {
                            System.out.println("Plato no encontrado: " + idPlato);
                        }
                    }

                    comandaDAO.crearComanda(comanda);

                    System.out.println("Comanda creada con éxito:");
                    System.out.println(comanda);
                }

                case 3 -> {
                    System.out.print("ID mesa: ");
                    Long id = Long.parseLong(sc.nextLine());
                    List<Comanda> lista = comandaDAO.comandasPorMesa(id);

                    lista.forEach(c -> {
                        System.out.println(c);
                        c.getItems().forEach(it ->
                                System.out.println("   - " + it.getPlato().getNombre() + " x" + it.getCantidad())
                        );
                    });
                }

                case 4 -> {
                    System.out.print("Categoria (entrada/principal/postre/bebida): ");
                    String cat = sc.nextLine();
                    platoDAO.listarPorCategoria(cat).forEach(System.out::println);
                }

                case 5 -> {
                    System.out.print("ID camarero: ");
                    Long idC = Long.parseLong(sc.nextLine());
                    System.out.print("Desde (yyyy-MM-ddTHH:mm) (ejemplo 2025-12-01T14:30): ");
                    LocalDateTime desde = LocalDateTime.parse(sc.nextLine());
                    System.out.print("Hasta (yyyy-MM-ddTHH:mm): ");
                    LocalDateTime hasta = LocalDateTime.parse(sc.nextLine());

                    Double total = comandaDAO.totalFacturadoPorCamarero(idC, desde, hasta);
                    System.out.println("Facturado: " + (total == null ? 0 : total) + " €");
                }

                case 6 -> {
                    System.out.print("ID cliente: ");
                    Long idCl = Long.parseLong(sc.nextLine());
                    System.out.print("Desde (yyyy-MM-ddTHH:mm) (ejemplo 2025-12-01T14:30): ");
                    LocalDateTime desde = LocalDateTime.parse(sc.nextLine());
                    System.out.print("Hasta (yyyy-MM-ddTHH:mm): ");
                    LocalDateTime hasta = LocalDateTime.parse(sc.nextLine());

                    Double total = comandaDAO.totalFacturadoPorCliente(idCl, desde, hasta);

                    System.out.println("Total facturado por cliente: " + (total == null ? 0 : total) + " €");
                }

                case 7 -> {
                    System.out.print("ID cliente: ");
                    Long idCl = Long.parseLong(sc.nextLine());
                    List<Comanda> cs = comandaDAO.comandasPorCliente(idCl);

                    cs.forEach(c ->
                            System.out.println(
                                    c +
                                            " | Mesa: " + (c.getMesa() != null ? c.getMesa().getNumero() : "-") +
                                            " | Camarero: " + (c.getCamarero() != null ? c.getCamarero().getNombre() : "-")
                            )
                    );
                }

                case 8 -> {
                    List<Object[]> res = mesaDAO.mesasOcupadasConCuentaComandas();
                    res.forEach(row -> {
                        Mesa m = (Mesa) row[0];
                        Long contador = (Long) row[1];
                        System.out.println(m + " -> nº comandas: " + contador);
                    });
                }

                case 9 -> {
                    System.out.print("ID mesa: ");
                    Long idM = Long.parseLong(sc.nextLine());
                    System.out.print("Nuevo estado (libre/ocupada): ");
                    String est = sc.nextLine();
                    mesaDAO.actualizarEstado(idM, est);
                    System.out.println("Estado actualizado.");
                }

                case 10 -> {
                    System.out.print("ID comanda: ");
                    Long idCo = Long.parseLong(sc.nextLine());
                    comandaDAO.eliminarComanda(idCo);
                    System.out.println("Comanda eliminada (si existía).");
                }

                case 11 -> {
                    List<Object[]> lista = comandaDAO.totalFacturadoPorCategoria();

                    System.out.println("\n--- Total facturado por categoría ---");
                    for (Object[] row : lista) {
                        String categoria = (String) row[0];
                        Double total = (Double) row[1];
                        System.out.println(categoria + ": " + (total == null ? 0 : total) + " €");
                    }
                }
            }

        } while (opt != 0);

        sc.close();
        HibernateUtil.shutdown();
    }
}
