package dao;

import modelo.Camarero;
import modelo.Comanda;
import util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.time.LocalDateTime;
import java.util.List;

public class CamareroDAO {


    public void guardar(Camarero c) {
        Transaction tx = null;
        try (Session s = HibernateUtil.getSessionFactory().openSession()) {
            tx = s.beginTransaction();
            s.persist(c);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        }
    }


    public Camarero obtener(Long id) {
        try (Session s = HibernateUtil.getSessionFactory().openSession()) {
            return s.find(Camarero.class, id);
        }
    }


    public List<Camarero> listarTodos() {
        try (Session s = HibernateUtil.getSessionFactory().openSession()) {
            return s.createQuery("FROM Camarero", Camarero.class).list();
        }
    }


    public void actualizar(Camarero c) {
        Transaction tx = null;
        try (Session s = HibernateUtil.getSessionFactory().openSession()) {
            tx = s.beginTransaction();
            s.merge(c);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        }
    }


    public void eliminar(Long id) {
        Transaction tx = null;
        try (Session s = HibernateUtil.getSessionFactory().openSession()) {
            Camarero c = s.find(Camarero.class, id);
            if (c == null) return;

            tx = s.beginTransaction();
            s.remove(c);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        }
    }


    public List<Comanda> listarComandasDeCamarero(Long idCamarero) {
        try (Session s = HibernateUtil.getSessionFactory().openSession()) {
            String hql = "FROM Comanda c WHERE c.camarero.id = :idCam";
            return s.createQuery(hql, Comanda.class)
                    .setParameter("idCam", idCamarero)
                    .list();
        }
    }
}
