package dao;

import modelo.Plato;
import util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.List;

public class PlatoDAO {


    public void guardar(Plato p) {
        Transaction tx = null;
        try (Session s = HibernateUtil.getSessionFactory().openSession()) {
            tx = s.beginTransaction();
            s.persist(p);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        }
    }


    public Plato obtener(Long id) {
        try (Session s = HibernateUtil.getSessionFactory().openSession()) {
            return s.find(Plato.class, id);
        }
    }


    public List<Plato> listarTodos() {
        try (Session s = HibernateUtil.getSessionFactory().openSession()) {
            return s.createQuery("FROM Plato", Plato.class).list();
        }
    }


    public void actualizar(Plato p) {
        Transaction tx = null;
        try (Session s = HibernateUtil.getSessionFactory().openSession()) {
            tx = s.beginTransaction();
            s.merge(p);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        }
    }


    public void eliminar(Long id) {
        Transaction tx = null;
        try (Session s = HibernateUtil.getSessionFactory().openSession()) {
            Plato p = s.find(Plato.class, id);
            if (p == null) return;

            tx = s.beginTransaction();
            s.remove(p);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        }
    }


    public List<Plato> listarPorCategoria(String categoria) {
        try (Session s = HibernateUtil.getSessionFactory().openSession()) {
            return s.createQuery("FROM Plato p WHERE p.categoria = :cat", Plato.class)
                    .setParameter("cat", categoria)
                    .list();
        }
    }

}
