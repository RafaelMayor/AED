package dao;

import modelo.Mesa;
import util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.List;

public class MesaDAO {


    public void guardar(Mesa m) {
        Transaction tx = null;
        try (Session s = HibernateUtil.getSessionFactory().openSession()) {
            tx = s.beginTransaction();
            s.persist(m);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        }
    }


    public Mesa obtener(Long id) {
        try (Session s = HibernateUtil.getSessionFactory().openSession()) {
            return s.find(Mesa.class, id);
        }
    }


    public List<Mesa> listarTodas() {
        try (Session s = HibernateUtil.getSessionFactory().openSession()) {
            return s.createQuery("FROM Mesa", Mesa.class).list();
        }
    }


    public void actualizar(Mesa m) {
        Transaction tx = null;
        try (Session s = HibernateUtil.getSessionFactory().openSession()) {
            tx = s.beginTransaction();
            s.merge(m);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        }
    }


    public void eliminar(Long id) {
        Transaction tx = null;
        try (Session s = HibernateUtil.getSessionFactory().openSession()) {
            Mesa m = s.find(Mesa.class, id);
            if (m == null) return;

            tx = s.beginTransaction();
            s.remove(m);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        }
    }


    public void actualizarEstado(Long idMesa, String estado) {
        Transaction tx = null;
        try (Session s = HibernateUtil.getSessionFactory().openSession()) {
            tx = s.beginTransaction();
            Mesa m = s.find(Mesa.class, idMesa);
            if (m != null) {
                m.setEstado(estado);
                s.merge(m);
            }
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        }
    }

    // Listar mesas ocupadas con número de comandas activas
    public List<Object[]> mesasOcupadasConCuentaComandas() {
        try (var s = HibernateUtil.getSessionFactory().openSession()) {
            String hql =
                    "SELECT m, COUNT(c) " +
                            "FROM Mesa m JOIN m.comandas c " +
                            "WHERE m.estado = 'ocupada' " +
                            "GROUP BY m";
            return s.createQuery(hql, Object[].class).list();
        }
    }
}
