package dao;

import modelo.Comanda;
import modelo.ComandaPlato;
import modelo.Plato;
import util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.time.LocalDateTime;
import java.util.List;

public class ComandaDAO {




    public Comanda crearComanda(Comanda comanda) {
        Transaction tx = null;

        try (Session s = HibernateUtil.getSessionFactory().openSession()) {
            tx = s.beginTransaction();

            // Asegurar que cada item conoce la comanda
            for (ComandaPlato cp : comanda.getItems()) {
                cp.setComanda(comanda);
            }

            s.persist(comanda);
            tx.commit();
            return comanda;

        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        }

        return null;
    }




    public Comanda obtener(Long id) {
        try (Session s = HibernateUtil.getSessionFactory().openSession()) {
            return s.find(Comanda.class, id);
        }
    }




    public List<Comanda> listarTodas() {
        try (Session s = HibernateUtil.getSessionFactory().openSession()) {
            return s.createQuery("FROM Comanda", Comanda.class).list();
        }
    }




    public void actualizar(Comanda comanda) {
        Transaction tx = null;

        try (Session s = HibernateUtil.getSessionFactory().openSession()) {
            tx = s.beginTransaction();
            s.merge(comanda);
            tx.commit();

        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        }
    }




    public void eliminarComanda(Long idComanda) {
        Transaction tx = null;

        try (Session s = HibernateUtil.getSessionFactory().openSession()) {
            tx = s.beginTransaction();

            Comanda c = s.find(Comanda.class, idComanda);
            if (c != null) s.remove(c);

            tx.commit();

        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        }
    }


    // Consultas HQL


    // Listar comandas de una mesa concreta
    public List<Comanda> comandasPorMesa(Long idMesa) {
        try (Session s = HibernateUtil.getSessionFactory().openSession()) {
            String hql = """
            SELECT DISTINCT c
            FROM Comanda c
            LEFT JOIN FETCH c.items cp
            LEFT JOIN FETCH cp.plato
            WHERE c.mesa.id = :idMesa
        """;

            return s.createQuery(hql, Comanda.class)
                    .setParameter("idMesa", idMesa)
                    .list();
        }
    }


    // Consultar comandas de un cliente mostrando mesa y camarero
    public List<Comanda> comandasPorCliente(Long idCliente) {
        try (Session s = HibernateUtil.getSessionFactory().openSession()) {
            String hql = "FROM Comanda c WHERE c.cliente.id = :idCli";
            return s.createQuery(hql, Comanda.class)
                    .setParameter("idCli", idCliente)
                    .list();
        }
    }

    // Total facturado por un camarero en un rango de fechas
    public Double totalFacturadoPorCamarero(Long idCamarero, LocalDateTime desde, LocalDateTime hasta) {
        try (Session s = HibernateUtil.getSessionFactory().openSession()) {

            String hql = """
                SELECT SUM(item.cantidad * p.precio)
                FROM Comanda c
                JOIN c.items item
                JOIN item.plato p
                WHERE c.camarero.id = :idCam
                AND c.fechaHora BETWEEN :ini AND :fin
            """;

            Double total = s.createQuery(hql, Double.class)
                    .setParameter("idCam", idCamarero)
                    .setParameter("ini", desde)
                    .setParameter("fin", hasta)
                    .uniqueResult();

            return total != null ? total : 0.0;
        }
    }

    // Total facturado por un cliente en un rango de fechas
    public Double totalFacturadoPorCliente(Long idCliente, LocalDateTime desde, LocalDateTime hasta) {
        try (Session s = HibernateUtil.getSessionFactory().openSession()) {

            String hql = """
                SELECT SUM(item.cantidad * p.precio)
                FROM Comanda c
                JOIN c.items item
                JOIN item.plato p
                WHERE c.cliente.id = :idCli
                AND c.fechaHora BETWEEN :ini AND :fin
            """;

            Double total = s.createQuery(hql, Double.class)
                    .setParameter("idCli", idCliente)
                    .setParameter("ini", desde)
                    .setParameter("fin", hasta)
                    .uniqueResult();

            return total != null ? total : 0.0;
        }
    }

    // Total facturado por categoría de plato
    public List<Object[]> totalFacturadoPorCategoria() {
        try (Session s = HibernateUtil.getSessionFactory().openSession()) {

            String hql = """
            SELECT p.categoria, SUM(cp.cantidad * p.precio)
            FROM Comanda c
            JOIN c.items cp
            JOIN cp.plato p
            GROUP BY p.categoria
        """;

            return s.createQuery(hql, Object[].class).list();
        }
    }
}
