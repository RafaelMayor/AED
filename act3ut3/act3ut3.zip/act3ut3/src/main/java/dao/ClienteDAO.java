package dao;

import modelo.Cliente;
import modelo.Comanda;
import util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.time.LocalDateTime;
import java.util.List;

public class ClienteDAO {


    public void guardar(Cliente c) {
        Transaction tx = null;
        try (Session s = HibernateUtil.getSessionFactory().openSession()) {
            tx = s.beginTransaction();
            s.persist(c);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        }
    }


    public Cliente obtener(Long id) {
        try (Session s = HibernateUtil.getSessionFactory().openSession()) {
            return s.find(Cliente.class, id);
        }
    }


    public List<Cliente> listarTodos() {
        try (Session s = HibernateUtil.getSessionFactory().openSession()) {
            return s.createQuery("FROM Cliente", Cliente.class).list();
        }
    }


    public void actualizar(Cliente c) {
        Transaction tx = null;
        try (Session s = HibernateUtil.getSessionFactory().openSession()) {
            tx = s.beginTransaction();
            s.merge(c);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        }
    }


    public void eliminar(Long id) {
        Transaction tx = null;
        try (Session s = HibernateUtil.getSessionFactory().openSession()) {
            Cliente c = s.find(Cliente.class, id);
            if (c == null) return;

            tx = s.beginTransaction();
            s.remove(c);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        }
    }


    public List<Comanda> listarComandasDeCliente(Long idCliente) {
        try (Session s = HibernateUtil.getSessionFactory().openSession()) {
            String hql = "FROM Comanda c WHERE c.cliente.id = :idCli";
            return s.createQuery(hql, Comanda.class)
                    .setParameter("idCli", idCliente)
                    .list();
        }
    }
}
