package modelo;

import jakarta.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "platos")
public class Plato {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nombre;
    private String descripcion;
    private double precio;

    // entrada, principal, postre, bebida
    private String categoria;

    // relación inversa con ComandaPlato
    @OneToMany(mappedBy = "plato", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<ComandaPlato> items = new HashSet<>();

    public Plato() {}
    public Plato(String nombre, String descripcion, double precio, String categoria) {
        this.nombre = nombre; this.descripcion = descripcion; this.precio = precio; this.categoria = categoria;
    }

    // getters y setters
    public Long getId() { return id; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
    public double getPrecio() { return precio; }
    public void setPrecio(double precio) { this.precio = precio; }
    public String getCategoria() { return categoria; }
    public void setCategoria(String categoria) { this.categoria = categoria; }
    public Set<ComandaPlato> getItems() { return items; }

    @Override
    public String toString() {
        return "Plato{id=" + id + ", nombre='" + nombre + "', precio=" + precio + ", categoria=" + categoria + "}";
    }
}
