package modelo;

import jakarta.persistence.*;

@Entity
@Table(name = "comanda_plato")
public class ComandaPlato {

    @EmbeddedId
    private ComandaPlatoId id = new ComandaPlatoId();

    @ManyToOne
    @MapsId("comandaId")
    @JoinColumn(name = "comanda_id")
    private Comanda comanda;

    @ManyToOne
    @MapsId("platoId")
    @JoinColumn(name = "plato_id")
    private Plato plato;

    private int cantidad;

    public ComandaPlato() {}
    public ComandaPlato(Comanda comanda, Plato plato, int cantidad) {
        this.comanda = comanda; this.plato = plato; this.cantidad = cantidad;
        if (comanda != null && plato != null) {
            this.id = new ComandaPlatoId(comanda.getId(), plato.getId());
        }
    }

    // getters y setters
    public ComandaPlatoId getId() { return id; }
    public Comanda getComanda() { return comanda; }
    public void setComanda(Comanda comanda) { this.comanda = comanda; }
    public Plato getPlato() { return plato; }
    public void setPlato(Plato plato) { this.plato = plato; }
    public int getCantidad() { return cantidad; }
    public void setCantidad(int cantidad) { this.cantidad = cantidad; }

    @Override
    public String toString() {
        return "ComandaPlato{comanda=" + (comanda != null ? comanda.getId() : null) +
                ", plato=" + (plato != null ? plato.getNombre() : null) + ", cantidad=" + cantidad + "}";
    }
}
