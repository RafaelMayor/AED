package modelo;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "comandas")
public class Comanda {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // fecha y hora de la comanda
    private LocalDateTime fechaHora;

    @ManyToOne
    @JoinColumn(name = "mesa_id")
    private Mesa mesa;

    @ManyToOne
    @JoinColumn(name = "camarero_id")
    private Camarero camarero;

    @ManyToOne
    @JoinColumn(name = "cliente_id")
    private Cliente cliente;

    // items (plato + cantidad) — entidad intermedia
    @OneToMany(mappedBy = "comanda", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<ComandaPlato> items = new HashSet<>();

    public Comanda() {}
    public Comanda(LocalDateTime fechaHora, Mesa mesa, Camarero camarero, Cliente cliente) {
        this.fechaHora = fechaHora; this.mesa = mesa; this.camarero = camarero; this.cliente = cliente;
    }

    // helpers para gestionar la relación bi-direccional
    public void addItem(ComandaPlato item) {
        items.add(item);
        item.setComanda(this);
    }
    public void removeItem(ComandaPlato item) {
        items.remove(item);
        item.setComanda(null);
    }

    // getters y setters
    public Long getId() { return id; }
    public LocalDateTime getFechaHora() { return fechaHora; }
    public void setFechaHora(LocalDateTime fechaHora) { this.fechaHora = fechaHora; }
    public Mesa getMesa() { return mesa; }
    public void setMesa(Mesa mesa) { this.mesa = mesa; }
    public Camarero getCamarero() { return camarero; }
    public void setCamarero(Camarero camarero) { this.camarero = camarero; }
    public Cliente getCliente() { return cliente; }
    public void setCliente(Cliente cliente) { this.cliente = cliente; }
    public Set<ComandaPlato> getItems() { return items; }

    @Override
    public String toString() {
        return "Comanda{id=" + id + ", fechaHora=" + fechaHora + ", mesa=" + (mesa != null ? mesa.getNumero() : null)
                + ", camarero=" + (camarero != null ? camarero.getNombre() : null) + ", cliente=" + (cliente != null ? cliente.getNombre() : null) + "}";
    }
}
