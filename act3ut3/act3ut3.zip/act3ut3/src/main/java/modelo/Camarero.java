package modelo;

import jakarta.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "camareros")
public class Camarero {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nombre;
    private String dni;

    @OneToMany(mappedBy = "camarero", cascade = CascadeType.ALL)
    private Set<Comanda> comandas = new HashSet<>();

    public Camarero() {}
    public Camarero(String nombre, String dni) { this.nombre = nombre; this.dni = dni; }

    // getters y setters
    public Long getId() { return id; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getDni() { return dni; }
    public void setDni(String dni) { this.dni = dni; }
    public Set<Comanda> getComandas() { return comandas; }

    @Override
    public String toString() { return "Camarero{id=" + id + ", nombre='" + nombre + "', dni='" + dni + "'}"; }
}
