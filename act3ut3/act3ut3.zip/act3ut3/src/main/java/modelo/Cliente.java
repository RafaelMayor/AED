package modelo;

import jakarta.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "clientes")
public class Cliente {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nombre;
    private String telefono;
    private String email;

    @OneToMany(mappedBy = "cliente", cascade = CascadeType.ALL)
    private Set<Comanda> comandas = new HashSet<>();

    public Cliente() {}
    public Cliente(String nombre, String telefono, String email) {
        this.nombre = nombre; this.telefono = telefono; this.email = email;
    }

    // getters y setters
    public Long getId() { return id; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public Set<Comanda> getComandas() { return comandas; }

    @Override
    public String toString() { return "Cliente{id=" + id + ", nombre='" + nombre + "'}"; }
}
