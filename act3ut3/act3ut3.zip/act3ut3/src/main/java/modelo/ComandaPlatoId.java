package modelo;

import jakarta.persistence.*;
import java.io.Serializable;
import java.util.Objects;

@Embeddable
public class ComandaPlatoId implements Serializable {
    private Long comandaId;
    private Long platoId;

    public ComandaPlatoId() {}
    public ComandaPlatoId(Long comandaId, Long platoId) { this.comandaId = comandaId; this.platoId = platoId; }

    // getters / setters
    public Long getComandaId() { return comandaId; }
    public void setComandaId(Long comandaId) { this.comandaId = comandaId; }
    public Long getPlatoId() { return platoId; }
    public void setPlatoId(Long platoId) { this.platoId = platoId; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ComandaPlatoId)) return false;
        ComandaPlatoId that = (ComandaPlatoId) o;
        return Objects.equals(comandaId, that.comandaId) && Objects.equals(platoId, that.platoId);
    }

    @Override
    public int hashCode() { return Objects.hash(comandaId, platoId); }
}
