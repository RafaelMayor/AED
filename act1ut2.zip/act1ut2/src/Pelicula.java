public class Pelicula {
    private int idPelicula;
    private String titulo;
    private String director;
    private String genero;
    private int anio;
    private int duracion;
    private double rating;
    private boolean disponible;

    public Pelicula() {}

    public Pelicula(String titulo, String director, String genero, int anio, int duracion, double rating, boolean disponible) {
        this.titulo = titulo;
        this.director = director;
        this.genero = genero;
        this.anio = anio;
        this.duracion = duracion;
        this.rating = rating;
        this.disponible = disponible;
    }

    public Pelicula(int idPelicula, String titulo, String director, String genero, int anio, int duracion, double rating, boolean disponible) {
        this(titulo, director, genero, anio, duracion, rating, disponible);
        this.idPelicula = idPelicula;
    }

    // Getters y Setters
    public int getIdPelicula() { return idPelicula; }
    public void setIdPelicula(int idPelicula) { this.idPelicula = idPelicula; }

    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }

    public String getDirector() { return director; }
    public void setDirector(String director) { this.director = director; }

    public String getGenero() { return genero; }
    public void setGenero(String genero) { this.genero = genero; }

    public int getAnio() { return anio; }
    public void setAnio(int anio) { this.anio = anio; }

    public int getDuracion() { return duracion; }
    public void setDuracion(int duracion) { this.duracion = duracion; }

    public double getRating() { return rating; }
    public void setRating(double rating) { this.rating = rating; }

    public boolean isDisponible() { return disponible; }
    public void setDisponible(boolean disponible) { this.disponible = disponible; }

    @Override
    public String toString() {
        return String.format("%s (%d) - Director: %s | Género: %s | Duración: %d min | Rating: %.1f | %s",
                titulo, anio, director, genero, duracion, rating, (disponible ? "Disponible" : "No disponible"));
    }
}