import java.util.*;

public class Main {
    public static void main(String[] args) {
        PeliculaDAO dao = new PeliculaDAO();
        /*
        // Inserts de prueba
        dao.insertar(new Pelicula("Inception", "Christopher Nolan", "Ciencia Ficcion", 2010, 148, 8.8, true));
        dao.insertar(new Pelicula("Interstellar", "Christopher Nolan", "Ciencia Ficcion", 2014, 169, 8.6, true));
        dao.insertar(new Pelicula("Tenet", "Christopher Nolan", "Accion", 2020, 150, 6.9, false));
        dao.insertar(new Pelicula("The Dark Knight", "Christopher Nolan", "Accion", 2008, 152, 9.0, true));
        dao.insertar(new Pelicula("Avatar", "James Cameron", "Ciencia Ficcion", 2009, 162, 7.8, true));
        dao.insertar(new Pelicula("Pulp Fiction", "Quentin Tarantino", "Crimen", 1994, 154, 8.9, true));
        dao.insertar(new Pelicula("Whiplash", "Damien Chazelle", "Drama", 2014, 107, 8.5, true));
        dao.insertar(new Pelicula("La La Land", "Damien Chazelle", "Musical", 2016, 128, 8.0, true));
        dao.insertar(new Pelicula("The Irishman", "Martin Scorsese", "Crimen", 2019, 209, 7.8, true));
        dao.insertar(new Pelicula("The Godfather", "Francis Ford Coppola", "Crimen", 1972, 175, 9.2, false));
        */
        Scanner sc = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("\n--- CATÁLOGO DE PELÍCULAS ---");
            System.out.println("1. Listar todas las películas");
            System.out.println("2. Buscar por género");
            System.out.println("3. Buscar por director (rating ≥ 7)");
            System.out.println("4. Listar disponibles después de 2015");
            System.out.println("5. Top 5 por rating");
            System.out.println("6. Buscar por palabra clave en título");
            System.out.println("7. Contar películas por género");
            System.out.println("8. Duración media por director");
            System.out.println("9. No disponibles con rating > 8");
            System.out.println("10. Más largas que la media");
            System.out.println("0. Salir");
            System.out.print("Opción: ");
            opcion = Integer.parseInt(sc.nextLine());

            switch (opcion) {
                case 1 -> dao.listarAlfabeticamente().forEach(System.out::println);
                case 2 -> {
                    System.out.print("Género: ");
                    dao.buscarPorGenero(sc.nextLine()).forEach(System.out::println);
                }
                case 3 -> {
                    System.out.print("Director: ");
                    dao.buscarPorDirectorRating(sc.nextLine()).forEach(System.out::println);
                }
                case 4 -> dao.disponiblesDesde2015().forEach(System.out::println);
                case 5 -> dao.top5Rating().forEach(System.out::println);
                case 6 -> {
                    System.out.print("Palabra clave: ");
                    dao.buscarPorPalabraClave(sc.nextLine()).forEach(System.out::println);
                }
                case 7 -> dao.contarPorGenero();
                case 8 -> {
                    System.out.print("Director: ");
                    dao.duracionMediaPorDirector(sc.nextLine());
                }
                case 9 -> dao.noDisponiblesRatingMayor8().forEach(System.out::println);
                case 10 -> dao.masLargasQueMedia().forEach(System.out::println);
                case 0 -> System.out.println("Saliendo...");
                default -> System.out.println("Opción no válida.");
            }
        } while (opcion != 0);
    }
}