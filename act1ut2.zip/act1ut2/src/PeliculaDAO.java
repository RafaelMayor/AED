import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PeliculaDAO {
    private final String url = "jdbc:sqlite:peliculas.db";

    public PeliculaDAO() {
        crearTabla();
    }

    private void crearTabla() {
        String sql = """
        CREATE TABLE IF NOT EXISTS Peliculas (
            id_pelicula INTEGER PRIMARY KEY AUTOINCREMENT,
            titulo TEXT NOT NULL,
            director TEXT,
            genero TEXT,
            anio INTEGER,
            duracion INTEGER,
            rating REAL,
            disponible INTEGER
        );
        """;
        try (Connection conn = DriverManager.getConnection(url);
             Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
        } catch (SQLException e) {
            System.out.println("Error al crear tabla: " + e.getMessage());
        }
    }


    public void insertar(Pelicula p) {
        String sql = "INSERT INTO Peliculas (titulo, director, genero, anio, duracion, rating, disponible) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(url);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, p.getTitulo());
            pstmt.setString(2, p.getDirector());
            pstmt.setString(3, p.getGenero());
            pstmt.setInt(4, p.getAnio());
            pstmt.setInt(5, p.getDuracion());
            pstmt.setDouble(6, p.getRating());
            pstmt.setInt(7, p.isDisponible() ? 1 : 0);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error al insertar: " + e.getMessage());
        }
    }

    // Consultas específicas
    public List<Pelicula> listarAlfabeticamente() {
        return obtenerLista("SELECT * FROM Peliculas ORDER BY titulo ASC");
    }

    public List<Pelicula> buscarPorGenero(String genero) {
        return obtenerLista("SELECT * FROM Peliculas WHERE genero LIKE '%" + genero + "%'");
    }

    public List<Pelicula> buscarPorDirectorRating(String director) {
        return obtenerLista("SELECT * FROM Peliculas WHERE director LIKE '%" + director + "%' AND rating >= 7");
    }

    public List<Pelicula> disponiblesDesde2015() {
        return obtenerLista("SELECT * FROM Peliculas WHERE disponible = 1 AND anio > 2015");
    }

    public List<Pelicula> top5Rating() {
        return obtenerLista("SELECT * FROM Peliculas ORDER BY rating DESC LIMIT 5");
    }

    public List<Pelicula> buscarPorPalabraClave(String palabra) {
        return obtenerLista("SELECT * FROM Peliculas WHERE titulo LIKE '%" + palabra + "%'");
    }

    public void contarPorGenero() {
        String sql = "SELECT genero, COUNT(*) AS total FROM Peliculas GROUP BY genero";
        try (Connection conn = DriverManager.getConnection(url);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                System.out.printf("%s -> %d películas%n", rs.getString("genero"), rs.getInt("total"));
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public void duracionMediaPorDirector(String director) {
        String sql = "SELECT AVG(duracion) AS media FROM Peliculas WHERE director LIKE '%" + director + "%'";
        try (Connection conn = DriverManager.getConnection(url);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) {
                System.out.printf("Duración media de las películas de %s: %.2f minutos%n", director, rs.getDouble("media"));
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public List<Pelicula> noDisponiblesRatingMayor8() {
        return obtenerLista("SELECT * FROM Peliculas WHERE disponible = 0 AND rating > 8");
    }

    public List<Pelicula> masLargasQueMedia() {
        String sql = """
            SELECT * FROM Peliculas
            WHERE duracion > (SELECT AVG(duracion) FROM Peliculas)
            ORDER BY duracion DESC
        """;
        return obtenerLista(sql);
    }


    private List<Pelicula> obtenerLista(String sql) {
        List<Pelicula> lista = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection(url);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                lista.add(new Pelicula(
                        rs.getInt("id_pelicula"),
                        rs.getString("titulo"),
                        rs.getString("director"),
                        rs.getString("genero"),
                        rs.getInt("anio"),
                        rs.getInt("duracion"),
                        rs.getDouble("rating"),
                        rs.getInt("disponible") == 1
                ));
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
        return lista;
    }
}