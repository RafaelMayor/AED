import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "divisiones")
public class Division {

    @Id
    @Column(length = 10)
    private String division; // Código de la división

    @Column(name = "nombre_division", nullable = false)
    private String nombreDivision;

    @Column(nullable = false)
    private String pais;

    @OneToMany(mappedBy = "divisionEntity")
    private List<Partido> partidos;

    public Division() {}

    public Division(String division, String nombreDivision, String pais) {
        this.division = division;
        this.nombreDivision = nombreDivision;
        this.pais = pais;
    }

    // Getters y setters
    public String getDivision() { return division; }
    public void setDivision(String division) { this.division = division; }
    public String getNombreDivision() { return nombreDivision; }
    public void setNombreDivision(String nombreDivision) { this.nombreDivision = nombreDivision; }
    public String getPais() { return pais; }
    public void setPais(String pais) { this.pais = pais; }
    public List<Partido> getPartidos() { return partidos; }
    public void setPartidos(List<Partido> partidos) { this.partidos = partidos; }

    @Override
    public String toString() {
        return "Division{" + "division='" + division + '\'' +
                ", nombreDivision='" + nombreDivision + '\'' +
                ", pais='" + pais + '\'' + '}';
    }
}
