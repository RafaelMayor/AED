import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        DivisionDAO divisionDAO = new DivisionDAO();
        PartidoDAO partidoDAO = new PartidoDAO();
        Scanner sc = new Scanner(System.in);
        int opcion = -1;

        while (opcion != 9) {
            System.out.println("\n===== MENÚ FÚTBOL =====");
            System.out.println("1. Crear División");
            System.out.println("2. Listar todas las Divisiones");
            System.out.println("3. Crear Partido");
            System.out.println("4. Listar todos los Partidos");
            System.out.println("5. Partidos en ligas de España");
            System.out.println("6. Partidos con goleada visitante (>=3 goles)");
            System.out.println("7. Actualizar Partido");
            System.out.println("8. Eliminar Partido por ID");
            System.out.println("9. Salir");
            System.out.print("Elige una opción: ");

            try {
                opcion = Integer.parseInt(sc.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Opción inválida.");
                continue;
            }

            switch (opcion) {
                case 1: // Crear División
                    System.out.print("Código división: ");
                    String cod = sc.nextLine();
                    System.out.print("Nombre división: ");
                    String nombre = sc.nextLine();
                    System.out.print("País: ");
                    String pais = sc.nextLine();
                    Division div = new Division(cod, nombre, pais);
                    divisionDAO.create(div);
                    System.out.println("División creada: " + div);
                    break;

                case 2: // Listar Divisiones
                    List<Division> divisiones = divisionDAO.findAll();
                    if (divisiones.isEmpty()) {
                        System.out.println("No hay divisiones.");
                    } else {
                        divisiones.forEach(System.out::println);
                    }
                    break;

                case 3: // Crear Partido
                    System.out.print("Código división: ");
                    String divCod = sc.nextLine();
                    Division division = divisionDAO.findById(divCod);
                    if (division == null) {
                        System.out.println("División no encontrada.");
                        break;
                    }
                    System.out.print("Fecha (AAAA-MM-DD): ");
                    LocalDate fecha = LocalDate.parse(sc.nextLine());
                    System.out.print("Equipo local: ");
                    String local = sc.nextLine();
                    System.out.print("Equipo visitante: ");
                    String visitante = sc.nextLine();
                    System.out.print("Goles local: ");
                    double golesLocal = Double.parseDouble(sc.nextLine());
                    System.out.print("Goles visitante: ");
                    double golesVisitante = Double.parseDouble(sc.nextLine());
                    System.out.print("Resultado final: ");
                    String resultado = sc.nextLine();
                    System.out.print("Temporada: ");
                    int temporada = Integer.parseInt(sc.nextLine());

                    Partido partido = new Partido(division, fecha, local, visitante,
                            golesLocal, golesVisitante, resultado, temporada);
                    partidoDAO.create(partido);
                    System.out.println("Partido creado: " + partido);
                    break;

                case 4: // Listar todos los partidos
                    List<Partido> partidos = partidoDAO.findAll();
                    if (partidos.isEmpty()) {
                        System.out.println("No hay partidos.");
                    } else {
                        partidos.forEach(System.out::println);
                    }
                    break;

                case 5: // Partidos en ligas de España
                    List<Partido> espana = partidoDAO.partidosEspaña();
                    if (espana.isEmpty()) {
                        System.out.println("No hay partidos en ligas de España.");
                    } else {
                        espana.forEach(System.out::println);
                    }
                    break;

                case 6: // Goleadas visitante
                    List<Partido> goleadas = partidoDAO.goleadasVisitante();
                    if (goleadas.isEmpty()) {
                        System.out.println("No hay goleadas visitantes.");
                    } else {
                        goleadas.forEach(System.out::println);
                    }
                    break;

                case 7: // Actualizar Partido
                    System.out.print("ID del partido a actualizar: ");
                    Long idUpd = Long.parseLong(sc.nextLine());
                    Partido pUpd = partidoDAO.findById(idUpd);
                    if (pUpd != null) {
                        System.out.print("Nuevo equipo local (actual: " + pUpd.getEquipoLocal() + "): ");
                        String newLocal = sc.nextLine();
                        if (!newLocal.isBlank()) pUpd.setEquipoLocal(newLocal);

                        System.out.print("Nuevo equipo visitante (actual: " + pUpd.getEquipoVisitante() + "): ");
                        String newVisitante = sc.nextLine();
                        if (!newVisitante.isBlank()) pUpd.setEquipoVisitante(newVisitante);

                        System.out.print("Goles local (actual: " + pUpd.getGolesLocal() + "): ");
                        String gLocal = sc.nextLine();
                        if (!gLocal.isBlank()) pUpd.setGolesLocal(Double.parseDouble(gLocal));

                        System.out.print("Goles visitante (actual: " + pUpd.getGolesVisitante() + "): ");
                        String gVisitante = sc.nextLine();
                        if (!gVisitante.isBlank()) pUpd.setGolesVisitante(Double.parseDouble(gVisitante));

                        partidoDAO.update(pUpd);
                        System.out.println("Partido actualizado: " + partidoDAO.findById(idUpd));
                    } else {
                        System.out.println("Partido no encontrado.");
                    }
                    break;

                case 8: // Eliminar Partido
                    System.out.print("ID del partido a eliminar: ");
                    Long idDel = Long.parseLong(sc.nextLine());
                    Partido pDel = partidoDAO.findById(idDel);
                    if (pDel != null) {
                        partidoDAO.delete(pDel);
                        System.out.println("Partido eliminado: " + pDel);
                    } else {
                        System.out.println("Partido no encontrado.");
                    }
                    break;

                case 9:
                    System.out.println("Saliendo...");
                    break;

                default:
                    System.out.println("Opción inválida.");
            }
        }

        sc.close();
        HibernateUtil.shutdown();
    }
}
