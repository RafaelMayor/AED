import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import java.util.List;

public class DivisionDAO {

    public void create(Division d) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Transaction tx = session.beginTransaction();
            session.persist(d);
            tx.commit();
        }
    }

    public Division findById(String id) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.find(Division.class, id);
        }
    }

    public List<Division> findAll() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<Division> query = session.createQuery("from Division", Division.class);
            return query.list();
        }
    }

    public void update(Division d) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Transaction tx = session.beginTransaction();
            session.merge(d);
            tx.commit();
        }
    }

    public void delete(Division d) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Transaction tx = session.beginTransaction();
            Division managed = session.contains(d) ? d : session.find(Division.class, d.getDivision());
            if (managed != null) session.remove(managed);
            tx.commit();
        }
    }
}
