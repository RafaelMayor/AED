import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import java.util.List;

public class PartidoDAO {

    public void create(Partido p) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Transaction tx = session.beginTransaction();
            session.persist(p);
            tx.commit();
        }
    }

    public Partido findById(Long id) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.find(Partido.class, id);
        }
    }

    public List<Partido> findAll() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<Partido> query = session.createQuery("from Partido", Partido.class);
            return query.list();
        }
    }

    public void update(Partido p) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Transaction tx = session.beginTransaction();
            session.merge(p);
            tx.commit();
        }
    }

    public void delete(Partido p) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Transaction tx = session.beginTransaction();
            Partido managed = session.contains(p) ? p : session.find(Partido.class, p.getIdPartido());
            if (managed != null) session.remove(managed);
            tx.commit();
        }
    }

    // HQL: todos los partidos en ligas de España
    public List<Partido> partidosEspaña() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<Partido> query = session.createQuery(
                    "from Partido p where p.divisionEntity.pais = :pais", Partido.class);
            query.setParameter("pais", "España");
            return query.list();
        }
    }

    // HQL: partidos donde el visitante gana por 3 o más goles
    public List<Partido> goleadasVisitante() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<Partido> query = session.createQuery(
                    "from Partido p where (p.golesVisitante - p.golesLocal) >= 3", Partido.class);
            return query.list();
        }
    }
}
