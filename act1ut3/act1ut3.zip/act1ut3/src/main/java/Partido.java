import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "partidos")
public class Partido {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idPartido;

    @ManyToOne
    @JoinColumn(name = "division")
    private Division divisionEntity;

    private LocalDate fechaPartido;

    @Column(nullable = false)
    private String equipoLocal;

    @Column(nullable = false)
    private String equipoVisitante;

    private double golesLocal;
    private double golesVisitante;

    private String resultadoFinal;

    private int temporada;

    public Partido() {}

    public Partido(Division divisionEntity, LocalDate fechaPartido, String equipoLocal,
                   String equipoVisitante, double golesLocal, double golesVisitante,
                   String resultadoFinal, int temporada) {
        this.divisionEntity = divisionEntity;
        this.fechaPartido = fechaPartido;
        this.equipoLocal = equipoLocal;
        this.equipoVisitante = equipoVisitante;
        this.golesLocal = golesLocal;
        this.golesVisitante = golesVisitante;
        this.resultadoFinal = resultadoFinal;
        this.temporada = temporada;
    }

    // Getters y setters
    public Long getIdPartido() { return idPartido; }
    public void setIdPartido(Long idPartido) { this.idPartido = idPartido; }
    public Division getDivisionEntity() { return divisionEntity; }
    public void setDivisionEntity(Division divisionEntity) { this.divisionEntity = divisionEntity; }
    public LocalDate getFechaPartido() { return fechaPartido; }
    public void setFechaPartido(LocalDate fechaPartido) { this.fechaPartido = fechaPartido; }
    public String getEquipoLocal() { return equipoLocal; }
    public void setEquipoLocal(String equipoLocal) { this.equipoLocal = equipoLocal; }
    public String getEquipoVisitante() { return equipoVisitante; }
    public void setEquipoVisitante(String equipoVisitante) { this.equipoVisitante = equipoVisitante; }
    public double getGolesLocal() { return golesLocal; }
    public void setGolesLocal(double golesLocal) { this.golesLocal = golesLocal; }
    public double getGolesVisitante() { return golesVisitante; }
    public void setGolesVisitante(double golesVisitante) { this.golesVisitante = golesVisitante; }
    public String getResultadoFinal() { return resultadoFinal; }
    public void setResultadoFinal(String resultadoFinal) { this.resultadoFinal = resultadoFinal; }
    public int getTemporada() { return temporada; }
    public void setTemporada(int temporada) { this.temporada = temporada; }

    @Override
    public String toString() {
        return "Partido{" + "idPartido=" + idPartido +
                ", division=" + divisionEntity.getDivision() +
                ", fechaPartido=" + fechaPartido +
                ", equipoLocal='" + equipoLocal + '\'' +
                ", equipoVisitante='" + equipoVisitante + '\'' +
                ", golesLocal=" + golesLocal +
                ", golesVisitante=" + golesVisitante +
                ", resultadoFinal='" + resultadoFinal + '\'' +
                ", temporada=" + temporada + '}';
    }
}
