import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class GenerarBD {

    public static void main(String[] args) {
        String url = "jdbc:sqlite:futbol.db";

        try (Connection conn = DriverManager.getConnection(url);
             Statement stmt = conn.createStatement()) {

            // Eliminar tablas si existen
            stmt.executeUpdate("DROP TABLE IF EXISTS partidos");
            stmt.executeUpdate("DROP TABLE IF EXISTS divisiones");

            // Crear tabla divisiones
            stmt.executeUpdate("""
                CREATE TABLE divisiones (
                    division TEXT PRIMARY KEY,
                    nombre_division TEXT NOT NULL,
                    pais TEXT NOT NULL
                );
            """);

            // Crear tabla partidos
            stmt.executeUpdate("""
                CREATE TABLE partidos (
                    idPartido INTEGER PRIMARY KEY AUTOINCREMENT,
                    division TEXT NOT NULL,
                    fechaPartido DATE NOT NULL,
                    equipoLocal TEXT NOT NULL,
                    equipoVisitante TEXT NOT NULL,
                    golesLocal REAL NOT NULL,
                    golesVisitante REAL NOT NULL,
                    resultadoFinal TEXT NOT NULL,
                    temporada INTEGER NOT NULL,
                    FOREIGN KEY (division) REFERENCES divisiones(division)
                );
            """);

            // Insertar divisiones
            stmt.executeUpdate("""
                INSERT INTO divisiones VALUES
                ('PR1', 'Primera División', 'España'),
                ('PR2', 'Segunda División', 'España'),
                ('EPL', 'Premier League', 'Inglaterra'),
                ('BUN', 'Bundesliga', 'Alemania'),
                ('SER', 'Serie A', 'Italia');
            """);

            // Insertar partidos
            stmt.executeUpdate("""
                INSERT INTO partidos (division, fechaPartido, equipoLocal, equipoVisitante, golesLocal, golesVisitante, resultadoFinal, temporada) VALUES
                ('PR1', '2024-09-10 00:00:00.000', 'Real Madrid', 'Barcelona', 2, 1, '2-1', 2024),
                ('PR1', '2024-10-12 00:00:00.000', 'Sevilla', 'Valencia', 0, 3, '0-3', 2024),
                ('PR2', '2024-09-15 00:00:00.000', 'Zaragoza', 'Granada', 1, 1, '1-1', 2024),
                ('EPL', '2024-09-22 00:00:00.000', 'Chelsea', 'Manchester City', 0, 4, '0-4', 2024),
                ('EPL', '2024-09-30 00:00:00.000', 'Arsenal', 'Liverpool', 3, 3, '3-3', 2024),
                ('BUN', '2024-09-25 00:00:00.000', 'Bayern Munich', 'Dortmund', 5, 0, '5-0', 2024),
                ('BUN', '2024-10-02 00:00:00.000', 'Leipzig', 'Union Berlin', 1, 4, '1-4', 2024),
                ('SER', '2024-09-28 00:00:00.000', 'Inter Milan', 'Juventus', 2, 2, '2-2', 2024),
                ('SER', '2024-10-10 00:00:00.000', 'Napoli', 'Roma', 0, 3, '0-3', 2024),
                ('PR1', '2024-10-05 00:00:00.000', 'Betis', 'Real Sociedad', 1, 4, '1-4', 2024),
                ('PR2', '2024-09-20 00:00:00.000', 'Levante', 'Tenerife', 0, 1, '0-1', 2024),
                ('EPL', '2024-10-10 00:00:00.000', 'Manchester United', 'Tottenham', 1, 0, '1-0', 2024),
                ('BUN', '2024-10-12 00:00:00.000', 'Stuttgart', 'Bayern Munich', 0, 3, '0-3', 2024),
                ('SER', '2024-10-15 00:00:00.000', 'Milan', 'Lazio', 4, 2, '4-2', 2024),
                ('PR1', '2024-10-20 00:00:00.000', 'Celta Vigo', 'Getafe', 0, 3, '0-3', 2024);
            """);

            System.out.println("Base de datos futbol.db generada correctamente.");

        } catch (Exception e) {
            System.err.println("Error al generar la base de datos: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
