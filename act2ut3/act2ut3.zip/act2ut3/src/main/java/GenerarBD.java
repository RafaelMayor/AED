import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class GenerarBD {

    public static void main(String[] args) {
        String url = "jdbc:sqlite:f1.db";

        try (Connection conn = DriverManager.getConnection(url);
             Statement stmt = conn.createStatement()) {

            // Eliminar tablas si existen
            stmt.executeUpdate("DROP TABLE IF EXISTS piloto_escuderia");
            stmt.executeUpdate("DROP TABLE IF EXISTS pilotos");
            stmt.executeUpdate("DROP TABLE IF EXISTS escuderias");

            // Crear tabla pilotos
            stmt.executeUpdate("""
                CREATE TABLE pilotos (
                    id_piloto INTEGER PRIMARY KEY AUTOINCREMENT,
                    nombre TEXT NOT NULL,
                    nacionalidad TEXT NOT NULL
                );
            """);

            // Crear tabla escuderias
            stmt.executeUpdate("""
                CREATE TABLE escuderias (
                    id_escuderia INTEGER PRIMARY KEY AUTOINCREMENT,
                    nombre TEXT NOT NULL,
                    sede TEXT NOT NULL
                );
            """);

            // Crear tabla intermedia
            stmt.executeUpdate("""
                CREATE TABLE piloto_escuderia (
                    piloto_id INTEGER NOT NULL,
                    escuderia_id INTEGER NOT NULL,
                    PRIMARY KEY (piloto_id, escuderia_id),
                    FOREIGN KEY (piloto_id) REFERENCES pilotos(id_piloto),
                    FOREIGN KEY (escuderia_id) REFERENCES escuderias(id_escuderia)
                );
            """);

            // Insertar pilotos
            stmt.executeUpdate("""
                INSERT INTO pilotos (nombre, nacionalidad) VALUES
                ('Fernando Alonso', 'España'),
                ('Lewis Hamilton', 'Reino Unido'),
                ('Max Verstappen', 'Países Bajos'),
                ('Charles Leclerc', 'Mónaco'),
                ('Carlos Sainz', 'España');
            """);

            // Insertar escuderías
            stmt.executeUpdate("""
                INSERT INTO escuderias (nombre, sede) VALUES
                ('Ferrari', 'Maranello, Italia'),
                ('Mercedes', 'Brackley, Reino Unido'),
                ('Red Bull Racing', 'Milton Keynes, Reino Unido'),
                ('McLaren', 'Woking, Reino Unido'),
                ('Renault/Alpine', 'Enstone, Reino Unido');
            """);

            // Insertar relaciones piloto ↔ escudería
            stmt.executeUpdate("""
                INSERT INTO piloto_escuderia VALUES
                (1, 4),   -- Alonso en McLaren
                (1, 5),   -- Alonso en Renault/Alpine
                (2, 2),   -- Hamilton en Mercedes
                (2, 4),   -- Hamilton en McLaren
                (3, 3),   -- Verstappen en Red Bull
                (4, 1),   -- Leclerc en Ferrari
                (5, 1),   -- Sainz en Ferrari
                (5, 5);   -- Sainz en Renault/Alpine
            """);

            System.out.println("Base de datos f1.db generada correctamente.");

        } catch (Exception e) {
            System.err.println("Error al generar la base de datos: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
