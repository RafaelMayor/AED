import modelo.*;
import dao.*;
import util.HibernateUtil;
import org.hibernate.Session;

import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        PilotoDAO pilotoDAO = new PilotoDAO();
        EscuderiaDAO escuderiaDAO = new EscuderiaDAO();

        while (true) {
            System.out.println("\n--- MENÚ FÓRMULA 1 ---");
            System.out.println("1. Crear piloto");
            System.out.println("2. Crear escudería");
            System.out.println("3. Asignar piloto a escudería");
            System.out.println("4. Mostrar pilotos de una escudería");
            System.out.println("5. Mostrar escuderías donde corrió un piloto");
            System.out.println("6. Pilotos de una nacionalidad en una escudería");
            System.out.println("7. Escuderías donde corrió un piloto por nombre");
            System.out.println("0. Salir");
            System.out.print("Opción: ");

            int op = Integer.parseInt(sc.nextLine());

            switch (op) {

                case 1 -> {
                    System.out.print("Nombre piloto: ");
                    String n = sc.nextLine();
                    System.out.print("Nacionalidad: ");
                    String nac = sc.nextLine();

                    pilotoDAO.guardar(new Piloto(n, nac));
                }

                case 2 -> {
                    System.out.print("Nombre escudería: ");
                    String n = sc.nextLine();
                    System.out.print("Sede: ");
                    String s = sc.nextLine();

                    escuderiaDAO.guardar(new Escuderia(n, s));
                }

                case 3 -> {
                    System.out.print("ID Piloto: ");
                    Long idP = Long.parseLong(sc.nextLine());
                    System.out.print("ID Escudería: ");
                    Long idE = Long.parseLong(sc.nextLine());

                    pilotoDAO.asignarEscuderia(idP, idE);
                    System.out.println("Asignado correctamente.");
                }

                case 4 -> {
                    System.out.print("ID Escudería: ");
                    Long id = Long.parseLong(sc.nextLine());

                    List<Piloto> pilotos = escuderiaDAO.getPilotosDeEscuderia(id);
                    pilotos.forEach(System.out::println);
                }

                case 5 -> {
                    System.out.print("ID Piloto: ");
                    Long id = Long.parseLong(sc.nextLine());

                    List<Escuderia> esc = pilotoDAO.getEscuderiasDePiloto(id);
                    esc.forEach(System.out::println);
                }

                case 6 -> {
                    System.out.print("Nacionalidad: ");
                    String nac = sc.nextLine();
                    System.out.print("Nombre escudería: ");
                    String escu = sc.nextLine();

                    Session session = HibernateUtil.getSessionFactory().openSession();
                    List<Piloto> lista = session.createQuery(
                                    "SELECT p FROM Piloto p JOIN p.escuderias e " +
                                            "WHERE p.nacionalidad = :n AND e.nombre = :en",
                                    Piloto.class)
                            .setParameter("n", nac)
                            .setParameter("en", escu)
                            .list();
                    session.close();

                    lista.forEach(System.out::println);
                }

                case 7 -> {
                    System.out.print("Nombre piloto: ");
                    String nombre = sc.nextLine();

                    Session session = HibernateUtil.getSessionFactory().openSession();
                    List<Escuderia> lista = session.createQuery(
                                    "SELECT e FROM Escuderia e JOIN e.pilotos p " +
                                            "WHERE p.nombre = :n",
                                    Escuderia.class)
                            .setParameter("n", nombre)
                            .list();
                    session.close();

                    lista.forEach(System.out::println);
                }

                case 0 -> {
                    System.out.println("Saliendo...");
                    HibernateUtil.getSessionFactory().close();
                    return;
                }
            }
        }
    }
}
