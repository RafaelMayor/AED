package modelo;

import jakarta.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "escuderias")
public class Escuderia {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_escuderia")
    private Long id;

    private String nombre;
    private String sede;

    @ManyToMany(mappedBy = "escuderias")
    private Set<Piloto> pilotos = new HashSet<>();

    public Escuderia() {}

    public Escuderia(String nombre, String sede) {
        this.nombre = nombre;
        this.sede = sede;
    }

    public Long getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getSede() {
        return sede;
    }

    public void setSede(String sede) {
        this.sede = sede;
    }

    public Set<Piloto> getPilotos() {
        return pilotos;
    }

    public void setPilotos(Set<Piloto> pilotos) {
        this.pilotos = pilotos;
    }

    @Override
    public String toString() {
        return "Escuderia{" + "id=" + id + ", nombre='" + nombre + '\'' +
                ", sede='" + sede + '\'' + '}';
    }
}
