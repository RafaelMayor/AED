package modelo;

import jakarta.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "pilotos")
public class Piloto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_piloto")
    private Long id;

    private String nombre;
    private String nacionalidad;

    @ManyToMany
    @JoinTable(
            name = "piloto_escuderia",
            joinColumns = @JoinColumn(name = "piloto_id"),
            inverseJoinColumns = @JoinColumn(name = "escuderia_id")
    )
    private Set<Escuderia> escuderias = new HashSet<>();

    public Piloto() {}

    public Piloto(String nombre, String nacionalidad) {
        this.nombre = nombre;
        this.nacionalidad = nacionalidad;
    }

    public Long getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNacionalidad() {
        return nacionalidad;
    }

    public void setNacionalidad(String nacionalidad) {
        this.nacionalidad = nacionalidad;
    }

    public Set<Escuderia> getEscuderias() {
        return escuderias;
    }

    public void setEscuderias(Set<Escuderia> escuderias) {
        this.escuderias = escuderias;
    }

    @Override
    public String toString() {
        return "Piloto{" + "id=" + id + ", nombre='" + nombre + '\'' +
                ", nacionalidad='" + nacionalidad + '\'' + '}';
    }
}
