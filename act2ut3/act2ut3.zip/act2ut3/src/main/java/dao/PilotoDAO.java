package dao;

import modelo.Piloto;
import modelo.Escuderia;
import org.hibernate.Session;
import org.hibernate.Transaction;
import util.HibernateUtil;

import java.util.List;

public class PilotoDAO {

    public void guardar(Piloto p) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.persist(p);
        tx.commit();
        session.close();
    }

    public Piloto obtener(Long id) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.find(Piloto.class, id);
        }
    }

    public List<Piloto> listar() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        List<Piloto> lista = session.createQuery("FROM Piloto", Piloto.class).list();
        session.close();
        return lista;
    }

    public void actualizar(Piloto p) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.merge(p);
        tx.commit();
        session.close();
    }

    public void eliminar(Piloto p) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.remove(p);
        tx.commit();
        session.close();
    }

    public void asignarEscuderia(Long idPiloto, Long idEscuderia) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();

        Piloto p = session.find(Piloto.class, idPiloto);
        Escuderia e = session.find(Escuderia.class, idEscuderia);

        if (p != null && e != null) {
            p.getEscuderias().add(e);
            e.getPilotos().add(p);
            session.merge(p);
        }

        tx.commit();
        session.close();
    }

    public List<Escuderia> getEscuderiasDePiloto(Long idPiloto) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        List<Escuderia> lista = session
                .createQuery("SELECT e FROM Piloto p JOIN p.escuderias e WHERE p.id = :id",
                        Escuderia.class)
                .setParameter("id", idPiloto)
                .list();
        session.close();
        return lista;
    }
}
