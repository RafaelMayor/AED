package dao;

import modelo.Escuderia;
import modelo.Piloto;
import org.hibernate.Session;
import org.hibernate.Transaction;
import util.HibernateUtil;

import java.util.List;

public class EscuderiaDAO {

    public void guardar(Escuderia e) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.persist(e);
        tx.commit();
        session.close();
    }

    public Escuderia obtener(Long id) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.find(Escuderia.class, id);
        }
    }

    public List<Escuderia> listar() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        List<Escuderia> lista = session.createQuery("FROM Escuderia", Escuderia.class).list();
        session.close();
        return lista;
    }

    public void actualizar(Escuderia e) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.merge(e);
        tx.commit();
        session.close();
    }

    public void eliminar(Escuderia e) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.remove(e);
        tx.commit();
        session.close();
    }

    public List<Piloto> getPilotosDeEscuderia(Long idEscuderia) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        List<Piloto> lista = session
                .createQuery("SELECT p FROM Escuderia e JOIN e.pilotos p WHERE e.id = :id",
                        Piloto.class)
                .setParameter("id", idEscuderia)
                .list();
        session.close();
        return lista;
    }
}
