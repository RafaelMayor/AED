package com.example.crudmesa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudmesaApplicationTests {

	@Test
	void contextLoads() {
	}

}
