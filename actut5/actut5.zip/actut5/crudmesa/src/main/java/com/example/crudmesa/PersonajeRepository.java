package com.example.crudmesa;

import org.springframework.data.jpa.repository.JpaRepository;

public interface PersonajeRepository
        extends JpaRepository<Personaje, Long> {
}
