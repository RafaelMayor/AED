package com.example.crudmesa;

import jakarta.persistence.*;

@Entity
public class Personaje {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nombre;
    private String clase;
    private int nivel;

    public Personaje() {}

    public Personaje(String nombre, String clase, int nivel) {
        this.nombre = nombre;
        this.clase = clase;
        this.nivel = nivel;
    }

    public Long getId() { return id; }

    public String getNombre() { return nombre; }

    public String getClase() { return clase; }

    public int getNivel() { return nivel; }

    public void setId(Long id) { this.id = id; }

    public void setNombre(String nombre) { this.nombre = nombre; }

    public void setClase(String clase) { this.clase = clase; }

    public void setNivel(int nivel) { this.nivel = nivel; }
}
