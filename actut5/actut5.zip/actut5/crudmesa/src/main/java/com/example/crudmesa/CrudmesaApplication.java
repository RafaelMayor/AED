package com.example.crudmesa;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.Scanner;

@SpringBootApplication
public class CrudmesaApplication {

    public static void main(String[] args) {
        SpringApplication.run(CrudmesaApplication.class, args);
    }

    @Bean
    CommandLineRunner ejecutar(PersonajeService service) {

        return args -> {

            Scanner sc = new Scanner(System.in);
            int opcion;

            do {
                System.out.println("\n--- MESA REDONDA ---");
                System.out.println("1. Crear personaje");
                System.out.println("2. Listar personajes");
                System.out.println("3. Subir nivel");
                System.out.println("4. Cambiar clase");
                System.out.println("5. Eliminar personaje");
                System.out.println("0. Abandonar las Tierras Intermedias");
                System.out.print("Opción: ");

                opcion = sc.nextInt();
                sc.nextLine();

                switch (opcion) {

                    case 1 -> {
                        System.out.print("Nombre: ");
                        String nombre = sc.nextLine();

                        System.out.print("Clase: ");
                        String clase = sc.nextLine();

                        System.out.print("Nivel inicial: ");
                        int nivel = sc.nextInt();
                        sc.nextLine();

                        try {
                            service.crear(new Personaje(nombre, clase, nivel));
                            System.out.println("Personaje creado correctamente");
                        } catch (Exception e) {
                            System.out.println("Error: " + e.getMessage());
                        }
                    }

                    case 2 -> {
                        System.out.println("\nLISTADO:");
                        service.listar().forEach(p ->
                                System.out.println(
                                        p.getId() + " - " +
                                        p.getNombre() + " - " +
                                        p.getClase() + " - Nivel " +
                                        p.getNivel()
                                )
                        );
                    }

                    case 3 -> {
                        System.out.print("ID del personaje: ");
                        Long id = sc.nextLong();

                        System.out.print("Subir niveles: ");
                        int subida = sc.nextInt();
                        sc.nextLine();

                        try {
                            service.subirNivel(id, subida);
                            System.out.println("Nivel actualizado");
                        } catch (Exception e) {
                            System.out.println("Error: " + e.getMessage());
                        }
                    }

                    case 4 -> {
                        System.out.print("ID del personaje: ");
                        Long id = sc.nextLong();
                        sc.nextLine();

                        System.out.print("Nueva clase: ");
                        String nuevaClase = sc.nextLine();

                        try {
                            service.cambiarClase(id, nuevaClase);
                            System.out.println("Clase cambiada");
                        } catch (Exception e) {
                            System.out.println("Error: " + e.getMessage());
                        }
                    }

                    case 5 -> {
                        System.out.print("ID del personaje: ");
                        Long id = sc.nextLong();
                        sc.nextLine();

                        service.borrar(id);
                        System.out.println("Personaje eliminado");
                    }
                }

            } while (opcion != 0);

            System.out.println("Has abandonado las Tierras Intermedias...");
        };
    }
}
