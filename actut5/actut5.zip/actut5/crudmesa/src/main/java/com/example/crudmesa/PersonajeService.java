package com.example.crudmesa;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class PersonajeService {

    private final PersonajeRepository repo;

    public PersonajeService(PersonajeRepository repo) {
        this.repo = repo;
    }


    public Personaje crear(Personaje p) {

        if (p.getNivel() < 1) {
            throw new IllegalArgumentException("El nivel inicial no puede ser menor que 1");
        }

        return repo.save(p);
    }


    public List<Personaje> listar() {
        return repo.findAll();
    }

    public Personaje buscar(Long id) {
        return repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Personaje no encontrado"));
    }


    public Personaje subirNivel(Long id, int aumento) {

        Personaje p = buscar(id);

        int nuevoNivel = p.getNivel() + aumento;

        if (nuevoNivel > 100) {
            nuevoNivel = 100;
        }

        p.setNivel(nuevoNivel);

        return repo.save(p);
    }


    public Personaje cambiarClase(Long id, String nuevaClase) {

        Personaje p = buscar(id);

        p.setClase(nuevaClase);

        return repo.save(p);
    }


    public void borrar(Long id) {
        repo.deleteById(id);
    }
}
