package com.example;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;

public class MongoDBConnection {

    // Cadena de conexión a MongoDB Atlas
    private static final String URI = "mongodb+srv://rmarmay2004:abdulmahamatamahaaa1234@cluster0.ygho6os.mongodb.net/?appName=Cluster0";

    // Nombre de la base de datos
    private static final String DATABASE = "concesionarioDB";

    public static MongoDatabase getDatabase() {
        MongoClient client = MongoClients.create(URI);
        return client.getDatabase(DATABASE);
    }
}
