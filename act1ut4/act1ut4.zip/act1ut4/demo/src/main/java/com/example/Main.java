package com.example;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        ClienteDAO clienteDAO = new ClienteDAO();
        VehiculoDAO vehiculoDAO = new VehiculoDAO();

        int opcion;

        do {
            System.out.println("\n--- MENÚ CONCESIONARIO ---");
            System.out.println("1. Insertar cliente");
            System.out.println("2. Listar clientes");
            System.out.println("3. Insertar vehículo");
            System.out.println("4. Listar todos los vehículos");
            System.out.println("5. Listar vehículos de un cliente");
            System.out.println("6. Marcar vehículo como vendido");
            System.out.println("7. Eliminar cliente");
            System.out.println("0. Salir");
            System.out.print("Opción: ");

            opcion = sc.nextInt();
            sc.nextLine();

            switch (opcion) {
                case 1:
                    System.out.print("DNI: ");
                    String dni = sc.nextLine();
                    System.out.print("Nombre: ");
                    String nombre = sc.nextLine();
                    System.out.print("Teléfono: ");
                    String telefono = sc.nextLine();
                    clienteDAO.insertarCliente(new Cliente(dni, nombre, telefono));
                    break;

                case 2:
                    clienteDAO.listarClientes();
                    break;

                case 3:
                    System.out.print("Matrícula: ");
                    String matricula = sc.nextLine();
                    System.out.print("Marca: ");
                    String marca = sc.nextLine();
                    System.out.print("Modelo: ");
                    String modelo = sc.nextLine();
                    System.out.print("Precio: ");
                    double precio = sc.nextDouble();
                    sc.nextLine();
                    System.out.print("DNI cliente: ");
                    String dniCliente = sc.nextLine();
                    vehiculoDAO.insertarVehiculo(
                            new Vehiculo(matricula, marca, modelo, precio, dniCliente));
                    break;

                case 4:
                    vehiculoDAO.listarVehiculos();
                    break;

                case 5:
                    System.out.print("DNI cliente: ");
                    String dniBuscar = sc.nextLine();
                    vehiculoDAO.listarVehiculosPorCliente(dniBuscar);
                    break;

                case 6:
                    System.out.print("Matrícula: ");
                    String mat = sc.nextLine();
                    vehiculoDAO.marcarVendido(mat);
                    break;

                case 7:
                    System.out.print("DNI cliente: ");
                    String dniEliminar = sc.nextLine();
                    clienteDAO.eliminarCliente(dniEliminar);
                    break;
            }

        } while (opcion != 0);

        sc.close();
    }
}
