package com.example;

import org.bson.Document;

import com.mongodb.client.MongoCollection;
import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Updates.set;

public class VehiculoDAO {

    private MongoCollection<Document> vehiculos;

    public VehiculoDAO() {
        vehiculos = MongoDBConnection
                .getDatabase()
                .getCollection("vehiculos");
    }

    public void insertarVehiculo(Vehiculo v) {
        Document doc = new Document("matricula", v.getMatricula())
                .append("marca", v.getMarca())
                .append("modelo", v.getModelo())
                .append("precio", v.getPrecio())
                .append("dniCliente", v.getDniCliente())
                .append("vendido", false);
        vehiculos.insertOne(doc);
    }

    public void listarVehiculos() {
        for (Document d : vehiculos.find()) {
            System.out.println(d.toJson());
        }
    }

    public void listarVehiculosPorCliente(String dni) {
        vehiculos.find(eq("dniCliente", dni))
                .forEach(d -> System.out.println(d.toJson()));
    }

    public void marcarVendido(String matricula) {
        vehiculos.updateOne(eq("matricula", matricula),
                set("vendido", true));
    }

    public void eliminarVehiculo(String matricula) {
        vehiculos.deleteOne(eq("matricula", matricula));
    }
}
