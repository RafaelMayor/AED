package com.example;

public class Vehiculo {
    private String matricula;
    private String marca;
    private String modelo;
    private double precio;
    private String dniCliente;
    private boolean vendido;

    public Vehiculo(String matricula, String marca, String modelo, double precio, String dniCliente) {
        this.matricula = matricula;
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
        this.dniCliente = dniCliente;
        this.vendido = false;
    }

    public String getMatricula() {
        return matricula;
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public double getPrecio() {
        return precio;
    }

    public String getDniCliente() {
        return dniCliente;
    }

    public boolean isVendido() {
        return vendido;
    }
}
