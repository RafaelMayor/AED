package com.example;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

import static com.mongodb.client.model.Filters.eq;

public class ClienteDAO {

    private MongoCollection<Document> clientes;
    private MongoCollection<Document> vehiculos;

    public ClienteDAO() {
        MongoDatabase db = MongoDBConnection.getDatabase();
        clientes = db.getCollection("clientes");
        vehiculos = db.getCollection("vehiculos");
    }

    public void insertarCliente(Cliente c) {
        Document doc = new Document("dni", c.getDni())
                .append("nombre", c.getNombre())
                .append("telefono", c.getTelefono());
        clientes.insertOne(doc);
    }

    public void listarClientes() {
        for (Document d : clientes.find()) {
            System.out.println(d.toJson());
        }
    }

    public void buscarClientePorDni(String dni) {
        Document d = clientes.find(eq("dni", dni)).first();
        if (d != null) {
            System.out.println(d.toJson());
        }
    }

    public void eliminarCliente(String dni) {
        long count = vehiculos.countDocuments(eq("dniCliente", dni));
        if (count == 0) {
            clientes.deleteOne(eq("dni", dni));
            System.out.println("Cliente eliminado");
        } else {
            System.out.println("No se puede eliminar, tiene vehículos asociados");
        }
    }
}
